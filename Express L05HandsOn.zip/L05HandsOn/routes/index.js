var express = require('express');
var router = express.Router();
var mysql = require('mysql2');
const models = require('../models');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/categories', function(req, res, next) {
  models.category.findAll({}).then(categoriesFound => {
    res.render('categories', {
      categories: categoriesFound
    })
  })
});

// Post route here(reference page 11)
// Use same HBS file as get route above
router.post('/category', (req, res) => {
  models.actor
    .findOrCreate({
      where: {
        first_name: req.body.name,
        last_name: req.body.default_price
      }
    })
    .spread(function(result, created) {
      if (created) {
        res.redirect('/category');
      } else {
        res.send('This category already exists!');
      }
    });
});
// Find by ID route (Reference page 9)
// Add new HBS file for single actor
router.get('/category/:id', function(req, res, next) {
  let categoryId = parseInt(req.params.id);
  models.category
    .findOne({
      where: {
        category_id: categoryId
      }
    })
    .then(category => {
      res.render('specificCategory', {
        category: category
      });
    });
});

module.exports = router;
